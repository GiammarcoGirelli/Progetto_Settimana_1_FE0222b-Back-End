import Macchina.Macchina;

public class Main {

    public static void main(String[] args) {
        Macchina[] arrayMacchina = new Macchina[5];

        arrayMacchina[0] = new Macchina("Fiat", 500, "BX444LK", 7.000, "Bluette", 5);
        arrayMacchina[1] = new Macchina("Peugeot", 1200, "CS556FV", 12.500, "Viola", 6);
        arrayMacchina[2] = new Macchina("Chevrolet", 1000, "BN998IF", 7.690, "Verde", 5);
        arrayMacchina[3] = new Macchina("Ford", 1800, "RM987BZ", 15.900, "Blu", 6);
        arrayMacchina[4] = new Macchina("Mazda", 1000, "TZ555BB", 13.700, "Bianco", 5);

        Macchina macchina1 = arrayMacchina[0];
        Macchina macchina2 = arrayMacchina[1];
        Macchina macchina3 = arrayMacchina[2];
        Macchina macchina4 = arrayMacchina[3];
        Macchina macchina5 = arrayMacchina[4];


        stampaMacchine(arrayMacchina);
        stampaMacchinaTarga(arrayMacchina);
        stampaMacchinaColore(arrayMacchina);
        selezionaMacchinaPrezzoPiuAlto(arrayMacchina);
        infoMacchina("BX444LK", arrayMacchina);
        infoMacchinaColore("Bluette", arrayMacchina);
        //infoMacchinaDaNome("Ford", arrayMacchina);
        motoreAccesoMacchina("Chevrolet",arrayMacchina);
    }

    static void stampaMacchine(Macchina[] arrayMacchina) {
        for (int i = 0; i < arrayMacchina.length; i++) {
            System.out.println("Stampa di prova macchina: " + i);
            System.out.println(arrayMacchina[i].stampaInformazioni());
        }

    }

    static void stampaMacchinaTarga(Macchina[] arrayMacchina) {
        for (int i = 0; i < arrayMacchina.length; i++) {
            System.out.println("Stampa solo targa macchina: " + i);
            System.out.println(arrayMacchina[i].getTarga());
        }

    }

    static void stampaMacchinaColore(Macchina[] arrayMacchina) {
        for (int i = 0; i < arrayMacchina.length; i++) {
            System.out.println("Stampa solo colore macchina: " + i);
            System.out.println(arrayMacchina[i].getColore());
        }

    }

    static void selezionaMacchinaPrezzoPiuAlto(Macchina[] arrayMacchina) {
        double max = 15.000;
        for (int i = 0; i < arrayMacchina.length; i++) {
            if (arrayMacchina[i].getPrezzo() > max) {
                max = arrayMacchina[i].getPrezzo();
                System.out.println("La macchina più costosa ha un valore di: " + max);
            }
        }

    }


    static void infoMacchina(String targa, Macchina[] arrayMacchina) {
        Macchina targaMacchina = null;
        for (int i = 0; i < arrayMacchina.length; i++) {
            if (targa.equals(arrayMacchina[i].getTarga())) {
                targaMacchina = arrayMacchina[i];
            }
        }
        if (targaMacchina == null) {
            throw new RuntimeException("Non hai inserito una targa esistente.");
        } else {
            System.out.println("La targa" + " " + targa + " " + "corrisponde alla macchina: " + targaMacchina.getNome());
        }
    }

    static void motoreAccesoMacchina(String nome, Macchina[] arrayMacchina){
        Macchina nomeSelezionatoMacchina = null;
        for (int i = 0; i < arrayMacchina.length; i++){
            if (nome.equals(arrayMacchina[i].getNome())){
                nomeSelezionatoMacchina = arrayMacchina[i];
            }
            if (nomeSelezionatoMacchina == null){
                System.out.println("La vettura inserita non è presente in officina.");
            } else {
                System.out.println("La vettura selezionata: " + nome + " adesso ha il motore acceso" + " " + nomeSelezionatoMacchina.isMotoreAcceso());
            }
        }
    }


    static void infoMacchinaColore(String colore, Macchina[] arrayMacchina) {
        Macchina coloreMacchina = null;
        for (int i = 0; i < arrayMacchina.length; i++) {
            if (colore.equals(arrayMacchina[i].getColore())) {
                coloreMacchina = arrayMacchina[i];
            }
        }
        if (coloreMacchina == null) {
            throw new RuntimeException("Non hai inserito un colore presente.");
        } else {
            System.out.println("La macchina di colore" + " " + colore + " " + "corrisponde a: " + coloreMacchina.getNome());
        }
    }

//    static void infoMacchinaDaNome(String nome, Macchina[] arrayMacchina) {
//        Macchina nomeMacchina = null;
//        for (int i = 0; i < arrayMacchina.length; i++) {
//            if (nome.equals(arrayMacchina[i].stampaInformazioni())) {
//                nomeMacchina = arrayMacchina[i];
//                }
//                }
//                if (nomeMacchina == null) {
//                    throw new RuntimeException("Non hai inserito una macchina esistente.");
//            } else {
//                System.out.println("La Macchina " + " " + nome + " " + " ha queste caratteristiche: " + arrayMacchina[1].stampaInformazioni());
//            }
//        }
//    }
}
